import dash
import pandas as pd

app = dash.Dash()
data = pd.read_csv("datasets/glaucoma_dataset.csv")